import mongoose from 'mongoose';
import 'dotenv/config';

const EXERCISE_DB_NAME = "Assignment_9";
const EXERCISE_COLLECTION = "exercises";
const EXERCISE_CLASS = 'exercise';

let connection = undefined;
let Exercises = undefined;

/**
 * This function does the following
 * 1. Connects to the MongoDB server
 * 2. Drop EXERCISE_COLLECTION if asked to
 * 3. Creates a model class for the exercise schema
 * @param {Boolean} dropCollection If true, drop EXERCISE_COLLECTION
 */
async function connect(dropCollection){
    try{
        connection = await createConnection();
        console.log("Successfully connected to MongoDB using Mongoose!");
        if(dropCollection){
            await connection.db.dropCollection(EXERCISE_COLLECTION);
        }
        Exercises = createModel();
    } catch(err){
        console.log(err)
        throw Error(`Could not connect to MongoDB ${err.message}`);
    }
}

/**
 * Connect to the MongoDB server for the connect string in .env file
 * @returns A connection to the server
 */
async function createConnection(){
    await mongoose.connect(process.env.MONGODB_CONNECT_STRING,
        {dbname: EXERCISE_DB_NAME});
    return mongoose.connection;
}

/**
 * Define a schema for the exercises collection, compile a model and return the model
 * @returns A model object for the exerciseSchema
 */
function createModel(){
    // Define the schema
    const exerciseSchema = mongoose.Schema({
        name: {type: String, required: true},
        reps: {type: Number, required: true},
        weight: {type: Number, required: true},
        unit: {type: String, required: true},
        date: {type: String, required: true},
    }
    );
    // Compile the model class from the schema after a schema is defined
    return mongoose.model(EXERCISE_CLASS, exerciseSchema);
}

/**
 * Creates a Excercises object and saves it to the database.
 * @returns a json object of the created document
 */
async function createExercise(name, reps, weight, unit, date){
    const exercise = new Exercises({name: name, reps: reps, weight: weight, unit: unit, date: date});
    return exercise.save();
}

/**
 * Finds all documents in the model
 * @returns a json array document objects
 */
async function findExercise(){
    const query = Exercises.find({});
    return query.exec();
}

/**
 * Finds the document matching the id
 * @returns a json object of the found document
 */
async function findExerciseById(id){
    let exercise = undefined;
    try {
        exercise = await Exercises.findById(id);
    } catch (error) {
        exercise = null;
    } finally {
        return exercise;
    }
}

/**
 * Updates a model document matching the _id
 * @returns an integer representing the number of documents modified
 */
async function updateExercise(_id, body){
    let modifiedCount = 0;

    try {
        const result = await Exercises.updateOne({_id: _id}, body);
        modifiedCount = result.modifiedCount;
    } catch (error) {
        console.log(error)
    } finally {
        return modifiedCount;
    }    
}

/**
 * Deletes the document in the database matching the _id
 * @returns the number of documents deleted from the database
 */
async function deleteExerciseById(_id){
    let deleteCount = undefined;
    try{
        const result = await Exercises.deleteOne({_id: _id});
        deleteCount = result.deletedCount;
    } catch(error){
        deleteCount = 0;
    } finally {
        return deleteCount;
    }
}

export { connect , createExercise, findExercise, findExerciseById, updateExercise, deleteExerciseById };