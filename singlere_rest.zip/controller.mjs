import express from 'express';
import * as model from './model.mjs';
import 'dotenv/config';
const app = express();

app.use(express.json());
await model.connect(true);

app.post('/exercises', async (req, res) => {

    //Parse the body from the request
    const name = req.body.name;
    const reps = req.body.reps;
    const weight = req.body.weight;
    const unit = req.body.unit;
    const date = req.body.date;

    if (!name || !reps || !weight || !unit || !date || Object.keys(req.body).length > 5 ||
        typeof(name) != 'string' || name.length < 1 || !Number.isInteger(reps) || reps < 0 ||
        !Number.isInteger(weight) || weight < 1 || typeof(unit) != 'string' || 
        (unit != 'kgs' && unit != 'lbs') || typeof(date) != 'string' || !isDateValid(date)){
        res.status(400).send({ Error: "Invalid request"});
    } else {
        // Create exercise document and send response
        res.status(201).send(await model.createExercise(name, reps, weight, unit, date));
    }
})

app.get('/exercises', async (req, res) => {
    // Find all documents in the model
    res.status(200).send(await model.findExercise());
})

app.get('/exercises/:id', async (req, res) => {
    // Parse id parameter and find document with id
    const id = req.params.id;
    const exercise = await model.findExerciseById(id);

    if (exercise){
        // Send response if user found
        res.status(200).send(exercise);
    } else{
        // Send response if user not found
        res.status(404).send({Error: "Not found"});
    }
})

app.put('/exercises/:id', async (req, res) => {
    //Parse the body from the request
    const name = req.body.name;
    const reps = req.body.reps;
    const weight = req.body.weight;
    const unit = req.body.unit;
    const date = req.body.date;

    if (!name || !reps || !weight || !unit || !date || Object.keys(req.body).length > 6 ||
        typeof(name) != 'string' || name.length < 1 || !Number.isInteger(reps) || reps < 0 ||
        !Number.isInteger(weight) || weight < 1 || typeof(unit) != 'string' || 
        (unit != 'kgs' && unit != 'lbs') || typeof(date) != 'string' || !isDateValid(date)){
        res.status(400).send({ Error: "Invalid request"});
    } else {
        // Parse the id parameter from the request
        const id = req.params.id;
        // Get the number of documents modified
        const modifiedCount = await model.updateExercise(id, req.body);
        if (modifiedCount == 1){
        // Send a response if one document was updated
        const exercise = await model.findExerciseById(id);
        res.status(200).send(exercise);
        } else{
            // Send a response of no documents were updated
            res.status(404).send({Error: "Not found"});
        }
    }
})

app.delete('/exercises/:id', async (req, res) => {
    // Parse the id from the request
    const id = req.params.id;
    // Delete document and get the delete count
    const deletedCount = await model.deleteExerciseById(id);
    if (deletedCount == 1){
        // If document deleted send success
        res.status(204).send();
    } else {
        // If document not found, send not found
        res.status(404).send({Error: "Not found"});
    }
})


/**
*
* @param {string} date
* Return true if the date format is MM-DD-YY where MM, DD and YY are 2 digit integers
*/
function isDateValid(date) {
    // Test using a regular expression. 
    // To learn about regular expressions see Chapter 6 of the text book
    const format = /^\d\d-\d\d-\d\d$/;
    return format.test(date);
}


app.listen(process.env.PORT, () => {
    console.log(`Server is listening on port ${process.env.PORT}...`);
});
